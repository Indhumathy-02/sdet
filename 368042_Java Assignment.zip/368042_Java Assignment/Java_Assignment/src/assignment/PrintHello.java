package assignment;

public class PrintHello {

	public static void main(String arg[])
	{ 
        System.out.println("Hello\nIndhumathy"); 
    } 
}

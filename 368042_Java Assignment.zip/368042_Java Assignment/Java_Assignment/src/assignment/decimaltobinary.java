package assignment;

import java.util.Scanner;

public class decimaltobinary {
	
	    public static void main(String[] args) 
	    {
	        int n, count = 0, i;
	        String x = "";
	        Scanner s = new Scanner(System.in);
	        System.out.print("Input any decimal number:");
	        n = s.nextInt();
	        while(n > 0)
	        {
	            i = n % 2;
	            if(i == 1)
	            {
	                count++;
	            }
	            x = i + "" + x;
	            n = n / 2;
	        }
	        System.out.println("Binary number:"+x);
	       
	    }
	}



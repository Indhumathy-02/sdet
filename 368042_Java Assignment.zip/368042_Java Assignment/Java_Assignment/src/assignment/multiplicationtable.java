package assignment;

public class multiplicationtable {
	public static void main(String arg[]) { 
	    int number = 8; 
	    for (int i = 1; i < 11; i++) { 
	        int result = number * i; 
	        System.out.println(number + "*" + i + "=" + result); 
	    } 
	} 

}

package assignment;

public class Calculator {

	
	public static void main(String arg[]) { 
	    int number1 = 125; 
	    int number2 = 24; 
	    int result = number1 + number2; 
	    int result1 = number1 - number2; 
	    int result2 = number1 * number2; 
	    int result3 = number1 / number2; 
	    int result4 = number1 % number2; 
	    System.out.println(result); 
	    System.out.println(result1); 
	    System.out.println(result2); 
	    System.out.println(result3); 
	    System.out.println(result4); 
	 
	} 
}

package task2;

public class charactertostring {
	public static void main(String[] args) {
        char ch = 'a';
        String st = Character.toString(ch);
        // Alternatively
        // st = String.valueOf(ch);

        System.out.println("The string is: " + st);
    }
}


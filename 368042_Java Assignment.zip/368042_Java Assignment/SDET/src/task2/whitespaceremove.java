package task2;

public class whitespaceremove {
	public static void main(String[] args) {  
        String str = "This is my World ";  
        //1st way  
        String noSpaceStr = str.replaceAll("\\s", ""); // using built in method  
        System.out.println(noSpaceStr);  
	}
}


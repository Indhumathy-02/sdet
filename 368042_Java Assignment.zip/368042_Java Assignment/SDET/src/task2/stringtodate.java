package task2;

import java.sql.Date;
import java.text.SimpleDateFormat;

public class stringtodate 
{
	public static void main(String[] args)throws Exception
	{  
    String sDate="31/12/1998";  
    java.util.Date date1=new SimpleDateFormat("dd/MM/yyyy").parse(sDate);  
    System.out.println(sDate+"\t"+date1);  
}  
}  

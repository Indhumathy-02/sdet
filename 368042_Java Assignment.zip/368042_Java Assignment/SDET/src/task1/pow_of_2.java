package task1;

import java.util.Scanner;

public class pow_of_2 {

	   public static void main(String args[]){
	        Scanner sc = new Scanner(System.in);
	        int Num_of_tests = sc.nextInt();
	        String[] results = new String[Num_of_tests];
	        for(int test=0;test<Num_of_tests;test++){
	            int input = sc.nextInt();
	            while(input>0){
	                if(input==1){
	                    results[test] = "YES";
	                    break;
	                }
	                else if(input%2==0){
	                    input/=2;
	                }
	                else{
	                    results[test] = "NO";
	                    break;
	                }
	                results[test] = "YES";
	            }
	        }
	        for(int index = 0;index<results.length;index++){
	            System.out.println("Result for test "+index+" is "+results[index]);
	        }
	    }
	}

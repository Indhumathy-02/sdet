package task4;

import java.util.Scanner;

public class repandnonrep {

	public static void main(String args[]){
        Scanner sc = new Scanner(System.in);
        String input = sc.nextLine();
        Boolean repeat_flag = false;
        int number_of_outputs = 0;
        for(int i=0;i<input.length();i++){
            repeat_flag = false;
            for(int j=i+1;j<input.length();j++){
                if(input.charAt(i)==input.charAt(j)){
                    repeat_flag = true;
                }
            }
            if(repeat_flag){
                System.out.println("The 1st repeated char is:"+input.charAt(i));
                number_of_outputs+=1;
            }
            if(!repeat_flag){
                System.out.println("The 1st non repeated char is:"+input.charAt(i));
                number_of_outputs+=1;
            }
            if(number_of_outputs>=2){
                break;
            }
        }
    }
}